from django.shortcuts import render,HttpResponse,redirect
from .models import addData
# Create your views here.
def index(request):
    return render(request,'index.html')

def table(request):
    data = addData.objects.all()
    # print('kaushal')
    # print(data)
    return render(request,'table.html',{'data':data})

def add(request):
    if request.method =='POST':
        name = request.POST.get('name')
        age = request.POST.get('age')
        clas = request.POST.get('clas')
        # for i in request.POST:
        #     print(i)
        # print(request.POST)
        # print(f'{name}, {age},{clas}')
        obj = addData()
        obj.name = name
        obj.age = age
        obj.clas = clas
        # print(f'{obj.name}, {obj.age},{obj.clas}')


        obj.save()
        return HttpResponse('RITU')
    return render(request,'table.html')


def update(request):
    id = request.GET.get('id')
    obj = addData.objects.get(pk=id)
    # print(id)
    # print(obj.name,obj.age,obj.clas)
    return render(request,'doUpdate.html',{'obj':obj})

def doupdate(request):
    id = request.GET.get('id')
    name = request.POST.get('name')
    age = request.POST.get('age')
    clas = request.POST.get('clas')
    obj = addData()
    obj.name = name
    obj.age = age
    obj.clas = clas



    obj.save()
    return redirect('/table')

def delete(request):
    id = request.GET.get('id')
    obj = addData.objects.get(pk=id)
    obj.delete()
    return redirect('/table')
