from django.shortcuts import render,HttpResponse

# Create your views here.
def table(request):
    return HttpResponse('Table')
def index(request):
    return HttpResponse('index')