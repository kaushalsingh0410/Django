from django.shortcuts import render, HttpResponse
from .models import Stu

# Create your views here.
def index(request):
    obj = Stu.objects.all()
    for i in obj:
        print('i',i.id)
        print('i',i.name)
    return render(request,'index.html',{'obj':obj})

def index1(request):
    
    return HttpResponse('index1')