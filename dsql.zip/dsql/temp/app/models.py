from django.db import models

# Create your models here.
class Stu(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=20)
    cla = models.CharField(max_length=10)
    age = models.SmallIntegerField()

    class Meta:
        db_table = 'stu' 

# class Stu1(models.Model):
#     id = models.AutoField(primary_key=True)
#     name = models.CharField(max_length=20)
#     cla = models.CharField(max_length=10)
#     age = models.SmallIntegerField()
#     class Meta:
#         db_table = 'stu1' 


