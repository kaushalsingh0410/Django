from django.shortcuts import render,HttpResponse
from django.http import JsonResponse
from .models import Ipl

import pandas as pd
import plotly.express as px
import plotly.offline as po

data_df = 1

def index(request):
    obj = Ipl.objects.all()

    data = []
    for i in obj:
        data.append({
            'match_id': i.match_id,
            'inning': i.inning,
            'batting_team': i.batting_team,
            'bowling_team': i.bowling_team,
            'over': i.over,
            'ball': i.ball,
            'batsman': i.batsman,
            'non_striker': i.non_striker,
            'bowler': i.bowler,
            'is_super_over': i.is_super_over,
            'wide_runs': i.wide_runs,
            'bye_runs': i.bye_runs,
            'legbye_runs': i.legbye_runs,
            'noball_runs': i.noball_runs,
            'penalty_runs': i.penalty_runs,
            'batsman_runs': i.batsman_runs,
            'extra_runs': i.extra_runs,
            'total_runs': i.total_runs,
            'player_dismissed': i.player_dismissed,
            'dismissal_kind': i.dismissal_kind,
            'fielder': i.fielder,
    })

    df = pd.DataFrame(data)
    global data_df
    data_df = df
    return render(request,'index.html',create_chart(data_df))


def create_chart(last_df):


    batsman_10 = last_df.groupby('batsman')['batsman_runs'].sum().sort_values(ascending = False).reset_index().head(10)
    fig = px.bar(batsman_10, x='batsman', y='batsman_runs').update_layout(xaxis_title = "Batsmans", yaxis_title="Runs")
    batsman_10 = po.plot(fig, output_type='div',auto_open=False)


    total_runs = last_df.groupby('batting_team')['batsman_runs'].sum().reset_index()
    fig = px.pie(total_runs, values='batsman_runs', names='batting_team')
    total_runs = po.plot(fig, output_type='div',auto_open=False)

    run_per_over = last_df.groupby(['batting_team','over'])['batsman_runs'].sum().reset_index()
    over_df = run_per_over.pivot(index = 'over',columns = 'batting_team',values = 'batsman_runs')
    fig = px.imshow(over_df, text_auto=True).update_layout(xaxis_title="Teams", yaxis_title="Number of overs")
    run_per_over = po.plot(fig, output_type='div',auto_open=False)

    idf = last_df.groupby(['batting_team','inning'])['batsman_runs'].sum().reset_index()
    idf = idf[(idf['inning'] == 1) | (idf['inning'] ==2 ) ]
    fig = px.histogram(idf, x="batting_team", y="batsman_runs",color='inning', barmode='group').update_layout(xaxis_title="Teams", yaxis_title="Runs")
    idf = po.plot(fig, output_type='div',auto_open=False)

    last_df['player_dismissed'].replace('','no',inplace = True)
    # print(temp_df)
    # print(last_df['player_dismissed'])
    wicket_df = last_df[last_df['player_dismissed'] !='no']['bowler'].value_counts().reset_index().head(10)
    # print(wicket_df)

    # print(wicket_df)
    fig = px.bar(wicket_df, x='bowler', y='count').update_layout(xaxis_title="Average", yaxis_title="Strike Rate")
    wicket_df = po.plot(fig, output_type='div',auto_open=False)


    top = last_df.groupby('batsman')['batsman_runs'].sum().sort_values(ascending=False).head(50).index
    top_df = last_df[last_df['batsman'].isin(top)]
    batsman = top_df.groupby('batsman')['batsman_runs'].sum()
    bowls = top_df.groupby('batsman')['batsman_runs'].count()
    sr = ((batsman/bowls)*100).reset_index()
    out = last_df[last_df['player_dismissed'].isin(top)]['player_dismissed'].value_counts()
    avg = batsman/out
    avg=avg.reset_index()
    avg = avg.merge(sr,left_on='index',right_on='batsman')[['index',0,'batsman_runs']]
    avg.rename(columns = {'index':'batsman',0:'avg','batsman_runs':'strike_rate'},inplace = True)
    fig = px.scatter(avg, x="avg", y="strike_rate",hover_name = 'batsman').update_layout(xaxis_title="Average", yaxis_title="Strike Rate")
    avg = po.plot(fig, output_type='div',auto_open=False)

    context ={
        'batsman_10':batsman_10,
        'total_runs':total_runs,
        'run_per_over':run_per_over,
        'idf':idf,
        'wicket_df':wicket_df,
        'avg':avg,
    }

    
    return context


def modify(request,number):
    last_df = 1
    if number ==1:
        last = data_df.tail(1).match_id.values[0]
        last_df = data_df[data_df['match_id']==last]
    elif number ==10:
        last_df =  data_df[data_df.match_id>data_df.match_id.max()-10]
    elif number ==100:
        last_df =  data_df[data_df.match_id>data_df.match_id.max()-100]
    elif number ==500:
        last_df =  data_df[data_df.match_id>data_df.match_id.max()-500]
    else:
        last_df = data_df

    print(last_df.head(1)['match_id'].values[0],last_df.tail(1)['match_id'].values[0])

    # create_chart(last_df)

    return JsonResponse({'chart':create_chart(last_df)})
    